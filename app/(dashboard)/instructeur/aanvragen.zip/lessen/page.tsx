import {
  CalendarCheck2,
  CalendarClock,
  CalendarDays,
  CircleX,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { LessonCreateDialog } from "@/components/instructor/lesson-create-dialog";
import { LessonsBoard } from "@/components/instructor/lessons-board";
import { getCurrentInstructorAvailability } from "@/lib/data/instructor-account";
import { getLocationOptions } from "@/lib/data/locations";
import {
  getInstructeurLessonRequests,
  getInstructeurLessons,
} from "@/lib/data/lesson-requests";
import { getCurrentInstructeurRecord } from "@/lib/data/profiles";
import { getInstructeurStudentsWorkspace } from "@/lib/data/student-progress";
import { resolveInstructorLessonDurationDefaults } from "@/lib/lesson-durations";

type LessonStatTone = "amber" | "blue" | "emerald" | "rose";

const statToneClasses: Record<LessonStatTone, string> = {
  amber: "border-amber-400/26 bg-amber-400/12 text-amber-300",
  blue: "border-blue-400/26 bg-blue-500/12 text-blue-300",
  emerald: "border-emerald-400/26 bg-emerald-500/12 text-emerald-300",
  rose: "border-rose-400/28 bg-rose-500/12 text-rose-300",
};

function isCurrentMonth(value: string | null | undefined) {
  if (!value) {
    return false;
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return false;
  }

  const now = new Date();
  return (
    date.getFullYear() === now.getFullYear() &&
    date.getMonth() === now.getMonth()
  );
}

function LessonStatCard({
  icon: Icon,
  label,
  tone,
  value,
}: {
  icon: LucideIcon;
  label: string;
  tone: LessonStatTone;
  value: string;
}) {
  return (
    <div className="rounded-lg border border-white/10 bg-[linear-gradient(145deg,rgba(255,255,255,0.06),rgba(15,23,42,0.34))] p-3.5 text-white shadow-[0_24px_70px_-52px_rgba(0,0,0,0.95)] 2xl:rounded-xl 2xl:p-5">
      <div className="flex items-center gap-3 2xl:gap-5">
        <span
          className={`flex size-11 shrink-0 items-center justify-center rounded-lg border 2xl:size-16 2xl:rounded-xl ${statToneClasses[tone]}`}
        >
          <Icon className="size-5 2xl:size-8" />
        </span>
        <div>
          <p className="text-sm text-slate-200 2xl:text-base">{label}</p>
          <p className="mt-1 text-2xl font-semibold tracking-tight text-white 2xl:mt-2 2xl:text-3xl">
            {value}
          </p>
          <p className="mt-1.5 text-xs text-slate-400 2xl:mt-3 2xl:text-sm">Deze maand</p>
        </div>
      </div>
    </div>
  );
}

export default async function InstructeurLessenPage({
  searchParams,
}: {
  searchParams: Promise<{ zoek?: string }>;
}) {
  const params = await searchParams;
  const [
    lessons,
    requests,
    slots,
    locationOptions,
    studentsWorkspace,
    instructeur,
  ] =
    await Promise.all([
      getInstructeurLessons(),
      getInstructeurLessonRequests(),
      getCurrentInstructorAvailability(),
      getLocationOptions(),
      getInstructeurStudentsWorkspace(),
      getCurrentInstructeurRecord(),
    ]);
  const durationDefaults = resolveInstructorLessonDurationDefaults(instructeur);
  const monthLessons = lessons.filter((lesson) =>
    isCurrentMonth(lesson.start_at),
  );
  const plannedLessons = monthLessons.filter((lesson) =>
    ["ingepland", "geaccepteerd"].includes(lesson.status),
  ).length;
  const completedLessons = monthLessons.filter(
    (lesson) => lesson.status === "afgerond",
  ).length;
  const cancelledLessons = monthLessons.filter(
    (lesson) => lesson.status === "geannuleerd",
  ).length;
  const lessonStats = [
    {
      icon: CalendarDays,
      label: "Totaal lessen",
      value: `${monthLessons.length}`,
      tone: "blue",
    },
    {
      icon: CalendarClock,
      label: "Ingepland",
      value: `${plannedLessons}`,
      tone: "amber",
    },
    {
      icon: CalendarCheck2,
      label: "Voltooid",
      value: `${completedLessons}`,
      tone: "emerald",
    },
    {
      icon: CircleX,
      label: "Geannuleerd",
      value: `${cancelledLessons}`,
      tone: "rose",
    },
  ] as const;

  return (
    <div className="space-y-4 text-white 2xl:space-y-7">
      <header className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between 2xl:gap-5">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-white sm:text-3xl 2xl:text-4xl">
            Lessen
          </h1>
          <p className="mt-1.5 text-sm text-slate-400 2xl:mt-2 2xl:text-lg">
            Beheer en overzicht van al je lessen en ingeplande afspraken.
          </p>
        </div>
        <LessonCreateDialog
          students={studentsWorkspace.students}
          locationOptions={locationOptions}
          durationDefaults={durationDefaults}
          className="h-9 rounded-lg bg-blue-600 px-4 text-sm text-white shadow-[0_18px_50px_-28px_rgba(37,99,235,0.9)] hover:bg-blue-500 2xl:h-11 2xl:px-5 2xl:text-base"
        />
      </header>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4 2xl:gap-5">
        {lessonStats.map((item) => (
          <LessonStatCard key={item.label} {...item} />
        ))}
      </div>

      <LessonsBoard
        lessons={lessons}
        requests={requests}
        slots={slots}
        students={studentsWorkspace.students}
        locationOptions={locationOptions}
        durationDefaults={durationDefaults}
        initialQuery={params.zoek ?? ""}
      />
    </div>
  );
}
